<?php
//UTF-8:SÍ
require_once "lo_imprescindible.php";
require_once "tabla_operativos.php";
require_once "metadatos_etoi252.php";
require_once "pdo_con_excepciones.php";
require_once "nuestro_mini_yaml_parse.php";

class Estructura_etoi252 extends Estructura_js{ 
}

?>