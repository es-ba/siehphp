<?phpetoi252
//UTF-8:SÍ
header('Location: etoi252.php');

?>